from fastapi import FastAPI, Depends
from dotenv import load_dotenv
import os
from sqlalchemy import text
from sqlalchemy.orm import Session
 
#importacao da configuracao inicial do banco de dados
from core.database import get_db
 
# Carrega variáveis de ambiente
load_dotenv()
app = FastAPI(
    title=os.getenv("APP_NAME","CUIDE_MAIS"),  
    version=os.getenv("APP_VERSION","1.0.0")
)
@app.get("/")
def read_root():
    return {"message": "Bem-vindo à API Cuide+"}
 
@app.get("/test-db")
def test_database_connetion(db: Session = Depends(get_db)):
    try:
        db.execute(text("SELECT 1"))
        return{"Status": "sucess", "message": "Conexão com Banco de Dados OK"}
    except Exception as error:
        return{"Status":"error","message": f"Falha na conexão: {error}"}